import java.util.Date;
public abstract class addTwo
{
    Date date;
    public abstract Object addTwo(Object o);
    public addTwo()
    {
        date = new Date();
        System.out.println("Parent constructor is called up which is displaying date" + date);
    }
    public String toString()
    {
        return "This will also be printed!";
    }
}