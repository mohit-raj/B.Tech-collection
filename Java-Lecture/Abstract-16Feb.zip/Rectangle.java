class Rectangle extends addTwo
     {
        double length,
               width,
               area,
               perimeter,
               diagonal;

        Rectangle ()
              {
				  length = 10;
				  width = 10;
				  perimeter = getPerimeter ();
				  area = getArea ();
				  diagonal = getDiagonal ();
		  }

	    public Object addTwo(Object o)
	    {
		    Rectangle temp = (Rectangle) o;
		    double side = Math.sqrt(temp.getArea() + this.getArea());
		    return new Rectangle(side);
	    }


       /* Rectangle addTwo (Rectangle r1, Rectangle r2)
              {
				 double side = Math.sqrt (r1.getArea() + r2.getArea ());
				 return new Rectangle (side);
		  }
        Rectangle addTwo (Rectangle r1)
              {
				  double side = Math.sqrt(r1.getArea() + this.getArea());
				  return new Rectangle (side);
	        }*/

        Rectangle (double l)
              {
				  length = l;
				  width = l;
				  perimeter = getPerimeter ();
				  area = getArea ();
				  diagonal = getDiagonal ();
			  }
        Rectangle (double l, double w)
              {
				  length = l;
				  width = w;
				  perimeter = getPerimeter ();
				  area = getArea ();
				  diagonal = getDiagonal ();
			  }
        double getLength ()
              {
                 return length;
              }
         double getWidth ()
              {
                 return width;
              }
        double getArea ()
              {
                 return length * width;
              }
        double getPerimeter ()
              {
                 return 2 * (length + width);
              }
        double getDiagonal ()
              {
                 return Math.sqrt (length * length + width * width);
              }
        void display ()
            {
				System.out.println
					("Length = " + this.length +
					", width = " + width +
					", perimeter = " + perimeter +
					", area = " + area +
					", diagonal = " + diagonal
					);
			}
		public static void main(String args [])
		{
			Rectangle r1 = new Rectangle();
			Rectangle r2 = new Rectangle();
			r2.display();
			r2 = (Rectangle) r2.addTwo(r1);
			r2.display();


			
			/*Rectangle r1 = new Rectangle();
			r1.display(); // displaying default values
			Rectangle r2 = new Rectangle(25.0);
			r2.display(); // displaying with one parameter
			
			Rectangle r3 = new Rectangle(40.0,50.0);
			r3.display(); // displaying with 2 parameters
			
			Rectangle r4 = new Rectangle();
			r4 = r4.addTwo(r1,r2);
			r4.display(); // Adding two rectangles with two parameters
			
			Rectangle r5 = new Rectangle();
			r5 = r5.addTwo(r2);
			r5.display(); //Adding two rectangles with one parameter*/
			
		}
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
     }