fprintf('Plotting Data ...\n')
data = load('Lattice_points.txt');
X = data(:, 1); y = data(:, 2);
m = length(y); % number of training examples

plotData(X, y);