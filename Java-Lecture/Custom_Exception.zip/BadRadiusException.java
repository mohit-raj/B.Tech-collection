public class BadRadiusException extends Exception
{
    public double radius;
    public BadRadiusException(double radius)
    {
        super("Bad Radius" + radius);
        this.radius = radius;
    }
}