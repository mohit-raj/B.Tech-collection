import java.util.Random;
public class useallThis
{
    public static void main(String args [])
    {
        int x = 0;
        Random random = new Random();
        x = random.nextInt(10000);
        Lion a = new Lion();
        Dolphin b = new Dolphin();
        mamalian m;
        if(x %2 == 0)
            m = a;
        else
            m = b;
        System.out.println(m.getClass() + " " + m.howdoesitMove() + " " + m.howdoesitTalk());
    }
}