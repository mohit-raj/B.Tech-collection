public class Lion extends Object implements mamalian,Edible
{
    public String howdoesitMove()
    {
        return "Springs and leans";
    }
    public String howdoesitTalk()
    {
        return "Roars";
    }
    public String canbeEaten()
    {
        return "must certainly not";
    }
}