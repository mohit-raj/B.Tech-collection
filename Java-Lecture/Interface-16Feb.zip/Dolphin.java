public class Dolphin extends Object implements mamalian,Edible
{
    public String howdoesitMove()
    {
        return "swims";
    }
    public String howdoesitTalk()
    {
        return "ultrasound waves";
    }
    public String canbeEaten()
    {
        return "Certainly not";
    }
}