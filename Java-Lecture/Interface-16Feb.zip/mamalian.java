public interface mamalian
{
    boolean hasHair = true;
    public String howdoesitMove();
    public String howdoesitTalk();
}