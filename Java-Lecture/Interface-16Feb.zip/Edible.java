public interface Edible
{
    public String canbeEaten();
}